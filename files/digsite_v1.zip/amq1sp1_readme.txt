===========================================================================
Title                   : Dig Site
Filename                : amq1sp1.bsp
Release date            : 3/28/2018
Author                  : Andrew Mushel
Email Address           : 
Other Files By Author   : 
Misc. Author Info       : 

Description             : A military base built on the ruins of an ancient site. Have they dug too deep?

Additional Credits to   : 
===========================================================================
* What is included *

New levels              : Yes
Sounds                  : No
Music                   : No
Graphics                : No
Other                   : No
Other files required    : No


* Play Information *

Single Player           : Designed for
Cooperative 2-4 Player  : No
Deathmatch 2-4 Player   : No
Difficulty Settings     : Not implemented


* Construction *

Base                    : New from scratch
Build Time              : Unknown
Editor(s) used          : TrenchBroom 2
Known Bugs              : None
May Not Run With        : Engines/exes known to have a problem with it
Tested With             : quakespasm 0.93.0



* Copyright / Permissions *

Authors (MAY/may NOT) use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.


You MAY distribute this file, provided you include this text file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.  I have received permission from the original authors of any
modified or included content in this file to allow further distribution.


* Where to get the file that this text file describes *

Web sites:
FTP sites: